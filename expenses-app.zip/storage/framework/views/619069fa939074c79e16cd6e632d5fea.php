

<div class="flex justify-center text-center w-[100px] p-3">
    <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="">
</div>
<?php /**PATH C:\Users\User\Desktop\expenses-app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>